from __future__ import annotations
from .cli import MAIN

# ENTRY POINT FOR `python -m food_waste_tracker`
# Startet das Programm über die Kommandozeile.
if __name__ == "__main__":
    MAIN()
